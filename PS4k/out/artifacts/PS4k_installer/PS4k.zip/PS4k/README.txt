For mac open console, navigate to PS4k folder and write

chmod 764 start.command

(only if right level not sufficient)